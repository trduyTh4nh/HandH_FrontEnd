import React from "react";

const Management: React.FC = () => {
    return (
        <>
            <h1 className="text-black">Management</h1>
        </>
    )
}


export default Management