import React from "react";

const PurchaseOrder: React.FC = () => {
    return (
        <>
            <h1 className="text-black">PurchaseOrder</h1>
        </>
    )
}


export default PurchaseOrder