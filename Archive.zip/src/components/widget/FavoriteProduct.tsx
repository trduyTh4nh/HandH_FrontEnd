import React from 'react'

export const FavoriteProduct: React.FC = () => {
  return (
    <div className='heght-div2 p-10 h-full'>FavoriteProduct</div>
  )
}
