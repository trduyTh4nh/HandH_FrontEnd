var listHistoryPayment = [
    {
        id: 1,
        time: '11/08/2024',
        code: 'abcxyz',
        momo: '0828907967',
        totalCost: 500000,
        quantity: 3,
        status: 'Đang được chuẩn bị',
        
    }
];
export default listHistoryPayment