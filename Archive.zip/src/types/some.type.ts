

export type TypeObjPrice = {
    lowPrice: number,
    highPrice: number
}

export type TypeFilterPice = {
    priceFilter: number,
    isHigher: boolean
}