const CustomerPage: React.FC = () => {
  return (
    <div className="h-screen w-screen">
      <h1>Customer Page</h1>
    </div>
  );
};

export default CustomerPage;
