const FinancetPage: React.FC = () => {
  return (
    <div className="h-screen w-screen">
      <h1>Financet Page</h1>
    </div>
  );
};

export default FinancetPage;
