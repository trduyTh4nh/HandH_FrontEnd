const OrderPage: React.FC = () => {
  return (
    <div className="h-screen w-screen">
      <h1>Order Page</h1>
    </div>
  );
};

export default OrderPage;
